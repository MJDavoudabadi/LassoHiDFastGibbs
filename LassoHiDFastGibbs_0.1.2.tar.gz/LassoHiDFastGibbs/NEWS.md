# LassoHiDFastGibbs 0.1.2

# LassoHiDFastGibbs 0.1.0

# LassoHiDFastGibbs 0.0.0.9000
- Initial development version.
