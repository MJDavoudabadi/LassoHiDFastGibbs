utils::globalVariables(
  c("mcmc_stats", "mcmc_diagnostics", "p")
)
